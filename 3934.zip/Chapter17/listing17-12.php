<html>
  <body>
    <?php echo $this->layout()->content; ?>
  </body>
</html>