<?php
class YourPrefix_Tax_Calculator {
  public static function calculate($a) {
    return $a * 1.07;
  }
}