<?php
class Zend_View_Helper_CurrentDate {
  public function currentDate() {
    return date("D M j");
  }
}