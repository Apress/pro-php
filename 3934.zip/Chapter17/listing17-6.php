<html>
  <body>
    <p>Current Date: <?php echo $this->currentDate(); ?></p>
  </body>
</html>