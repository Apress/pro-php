Zend_Layout::startMvc(
  array(
    'layoutPath' => APP_PATH . '/application/layouts/',
    'layout' => 'index'
  )
);
