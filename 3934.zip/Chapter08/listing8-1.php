<?php
class Demo {
  public function sum($a,$b) {
    return $a+$b;
  }
  public function subtract($a,$b) {
    return $a-$b;
  }
}