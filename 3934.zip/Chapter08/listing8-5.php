<?php
require_once('Demo.php');

$demo = new Demo();
echo "Two plus Two = ". $demo->sum(2,2);