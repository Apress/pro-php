xdebug_start_trace('trace');
$a->myCaller($b);
xdebug_stop_trace();