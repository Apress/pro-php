/**
This is a doccomment that is associated with a function
*/
function notimportant() {}

/*
This is not a doccomment because it does not start with a slash-star-star
*/
function notimportant{}

/**
This is a doccomment but it is not associated with the function
*/

function notimportant() {}