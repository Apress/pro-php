class MyObject {

  public static $myVariable = 10;

}

echo MyObject::$myVariable;