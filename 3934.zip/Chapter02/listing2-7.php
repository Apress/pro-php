class MyObject {

  static function myMethod() {
    //Do something useful
  }

}

MyObject::myMethod();