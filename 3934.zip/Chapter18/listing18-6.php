<?php
echo json_encode(microtime(true));