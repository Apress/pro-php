[group1]
mykey=myvalue