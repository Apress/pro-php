public function redirectAction() {
  $this->getHelper('redirector')->goto('index');
}