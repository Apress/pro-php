<?php
class Customers extends Zend_Db_Table {
  protected $_name = 'customers';
  protected $_primary = 'customer_id';
}