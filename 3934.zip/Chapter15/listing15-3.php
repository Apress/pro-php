<html>
  <body>
    <p>Welcome: <?php echo $this->name; ?></p>
  </body>
</html>