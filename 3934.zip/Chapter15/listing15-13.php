<form method="post" action="/customers/add">
  <?php echo $this->formText('name'); ?>
  <?php echo $this->formSubmit('submit'); ?>
</form>