public function addAction() {
  Zend_Debug::dump($this->getRequest()->getPost());
}