public function indexAction() {
  $this->view->name = 'Kevin';
}