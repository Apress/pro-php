$validation = array(
  'name' => array (
    array('StringLength', 1, 64),
    'Alpha'
  )
);