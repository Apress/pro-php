$validation = array(
  'name' => array (
    'Alpha',
    Zend_Filter_Input::ALLOW_EMPTY => true
  )
);