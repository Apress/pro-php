interface IPlugin {
  public static function getName();
}