<?php
$standard = "abcde";
echo $standard ." ". strlen($standard) . "\n";

$unicode = "ᐁᐂᐃᐄᐅ";
echo $unicode ." ". strlen($unicode) . "\n";
