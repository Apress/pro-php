<?php
require_once('Vector.php');

$line = new Vector::Line();
$line->draw(1,1,10,10);