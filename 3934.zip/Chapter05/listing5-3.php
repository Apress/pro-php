<?php
  phpinfo();