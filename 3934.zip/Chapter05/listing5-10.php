<?php
require_once('Vector.php');

use Vector::Line as Line;

$line = new Line();
$line->draw(1,1,10,10);