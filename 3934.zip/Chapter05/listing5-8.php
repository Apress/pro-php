<?php
namespace Vector;

class Line {
  public function draw($x1, $y1, $x2, $y2) { . . . }
}