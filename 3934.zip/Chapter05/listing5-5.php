<?php
$binary = b"ᐁᐂᐃᐄᐅ";
echo $binary ." ". strlen($binary);
