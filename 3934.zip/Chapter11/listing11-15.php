$it = new CSVFileObject('pm.csv');
var_dump(iterator_to_array($it));