function Demo($param1) {
  return 'Request received with param1 = '. $param1;
}