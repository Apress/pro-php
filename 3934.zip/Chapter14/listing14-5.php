<?php

interface IController {}