class a {}
$instance = new a();
echo spl_object_hash($instance);