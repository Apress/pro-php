$street = new Street();
$street->addCar(new FastCar());