abstract class Car {

  //Any base class methods

  abstract function getMaximumSpeed();

}