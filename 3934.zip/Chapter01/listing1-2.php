class FastCar extends Car {

  function getMaximumSpeed() {
    return 150;
  }

}