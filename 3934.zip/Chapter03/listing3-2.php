$db = Database::getInstance();
$db->query('SELECT * FROM example_table');