class SomeClass {

  //Prevent the class from being used as an instance
  private function __construct() {}

  public static function SomeMethod() {
    //Do something
  }

}